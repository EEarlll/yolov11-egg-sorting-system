# Egg Crack Detection > 2025-01-29 1:22pm
https://universe.roboflow.com/ae-3rclr/egg-crack-detection-ajv0f-ls3uc

Provided by a Roboflow user
License: CC BY 4.0

